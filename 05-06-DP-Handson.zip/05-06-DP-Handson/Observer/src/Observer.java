
public interface Observer {
	public void update(Message m);
}
